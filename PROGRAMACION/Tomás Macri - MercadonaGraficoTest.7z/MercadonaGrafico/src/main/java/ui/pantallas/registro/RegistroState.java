package ui.pantallas.registro;

public class RegistroState {
}
