package ui.pantallas.commonPantallas;

public class ConstantesPantallas {

    public static final String FXML_PANTALLA_NUEVA_FXML = "/fxml/pantallaNueva.fxml";
    public static final String FXML_MAIN_ADMIN_FXML = "/fxml/mainAdmin.fxml";
    public static final String FXML_LOGIN_FXML = "/fxml/login.fxml";
    public static final String FXML_REGISTRO_FXML = "/fxml/registro.fxml";
    public static final String FXML_EDITAR_PRODUCTO_FXML = "/fxml/editarProducto.fxml";
    public static final String FXML_EDITAR_USUARIO_FXML = "/fxml/editarUsuario.fxml";
    public static final String FXML_MAIN_CLIENTE_FXML = "/fxml/mainCliente.fxml";
    public static final String FXML_COMPRAS_FXML = "/fxml/compras.fxml";
}
