package ui.pantallas.compras;

public class ComprasViewModel {
}
