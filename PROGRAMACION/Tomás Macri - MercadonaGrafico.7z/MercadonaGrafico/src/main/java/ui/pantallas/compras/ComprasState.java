package ui.pantallas.compras;

public class ComprasState {
}
