package ui.pantallas.registro;

public class RegistroViewModel {
}
