package ui.pantallas.registro;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.text.Text;
import ui.pantallas.commonPantallas.BasePantallaController;

public class RegistroController extends BasePantallaController implements Initializable {

    @FXML
    private Text txtText;



    @Override
    public void initialize(java.net.URL location, java.util.ResourceBundle resources) {
        //txtText.setText("Registro");
    }
}
