package modelo;

public interface Clonable<T> {

    T clonar();
}
