package ui.pantallas.commonPantallas;

public class BaseViewModel {
}
