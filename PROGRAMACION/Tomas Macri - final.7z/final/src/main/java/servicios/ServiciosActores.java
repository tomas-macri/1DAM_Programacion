package servicios;

import modelo.Actor;

import java.util.List;

public interface ServiciosActores {
    List<Actor> getTodosLosActores();
}
