package dao;

import modelo.Actor;

import java.util.List;

public interface DaoActores {
    List<Actor> getTodosLosActores();
}
