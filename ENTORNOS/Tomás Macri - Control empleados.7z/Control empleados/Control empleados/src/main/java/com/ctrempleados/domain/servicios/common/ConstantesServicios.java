package com.ctrempleados.domain.servicios.common;

public class ConstantesServicios {
    public static final String NO_EXISTE_UN_EMPLEADO_CON_ESE_CÓDIGO_DE_ACCESO = "No existe un empleado con ese código de acceso";
    public static final String NO_HAY_NOMINAS = "Error - No hay nominas";
    public static final String NO_HAY_REGISTROS_DEL_EMPLEADO = "No hay registros del empleado";
}
