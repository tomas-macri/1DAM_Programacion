package com.ctrempleados.domain.modelo.common;

public class ConstantesModelo {
    public static final String D = "d, ";
    public static final String M = "m";
    public static final String DOS_PUNTOS = ":";
    public static final String DD_MM_YYYY_HH_MM_SS = "dd/MM/yyyy HH:mm:ss";
}
